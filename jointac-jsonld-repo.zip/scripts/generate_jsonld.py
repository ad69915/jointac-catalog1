# -*- coding: utf-8 -*-
import json, os, sys
import pandas as pd
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DIST = ROOT / "dist" / "jsonld"
DIST.mkdir(parents=True, exist_ok=True)

def product_row_to_jsonld(row: pd.Series) -> dict:
    ap = []
    for k in ["材質","供電方式","功能特點","符合標準/認證","適用場景","配件/選配","保固/維護","產地"]:
        v = str(row.get(k, "") or "").strip()
        if v:
            ap.append({"@type":"PropertyValue","name":k,"value":v})
    prod = {
        "@context":"https://schema.org",
        "@type":"Product",
        "name": str(row.get("產品名稱","")).strip(),
        "model": str(row.get("型號","")).strip() or None,
        "category": str(row.get("分類","道路安全設備")),
        "description": str(row.get("規格(尺寸/功率/等級)","")),
        "brand": {"@type":"Brand","name": str(row.get("公司名稱","展通交通器材有限公司"))},
        "image": [str(row.get("圖片URL","")).strip()] if str(row.get("圖片URL","")).strip() else [],
        "url": str(row.get("產品頁URL","")).strip(),
        "additionalProperty": ap,
        "offers": {"@type":"Offer","url": str(row.get("產品頁URL","")).strip(), "priceCurrency":"TWD"}
    }
    return prod

def collection_jsonld(name: str, items: list) -> dict:
    return {
        "@context":"https://schema.org",
        "@type":"ProductCollection",
        "name": name,
        "url": "https://www.jointac.tw/product.php",
        "brand": {"@type":"Brand","name":"展通交通器材有限公司"},
        "hasOfferCatalog": {
            "@type":"OfferCatalog",
            "name": f"{name} 目錄",
            "itemListElement": items
        },
        "publisher":{"@type":"Organization","name":"展通交通器材有限公司","url":"https://www.jointac.tw/"}
    }

def faq_jsonld(rows: pd.DataFrame) -> dict:
    ents = []
    for _, r in rows.iterrows():
        q = str(r.get("問題","")).strip()
        a = str(r.get("答案","")).strip()
        if not q or not a: 
            continue
        ents.append({"@type":"Question","name":q,"acceptedAnswer":{"@type":"Answer","text":a}})
    return {"@context":"https://schema.org","@type":"FAQPage","mainEntity":ents}

def main():
    prod_csv = DATA / "products.csv"
    faq_csv  = DATA / "faq.csv"
    if not prod_csv.exists():
        print("找不到 data/products.csv，請先填好再執行。"); sys.exit(1)

    df = pd.read_csv(prod_csv)
    # 單品 JSON-LD 批次
    products = []
    for _, r in df.iterrows():
        jd = product_row_to_jsonld(r)
        products.append(jd)
        # 個別檔
        fname = f"{r.get('產品名稱','product').strip()}".replace("/","_").replace(" ","_") + ".jsonld"
        with open(DIST / fname, "w", encoding="utf-8") as f:
            json.dump(jd, f, ensure_ascii=False, indent=2)

    with open(DIST / "products_all.jsonld", "w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=2)

    # 分類集合
    by_cat = defaultdict(list)
    for p in products:
        by_cat[p.get("category","未分類")].append({
            "@type":"Product","name":p["name"],"url":p["url"],
            "image": p.get("image",[])[0] if p.get("image") else None
        })
    for cat, items in by_cat.items():
        col = collection_jsonld(cat, items)
        fname = f"collection_{cat}.jsonld".replace("/","_").replace(" ","_")
        with open(DIST / fname, "w", encoding="utf-8") as f:
            json.dump(col, f, ensure_ascii=False, indent=2)

    # FAQ
    if faq_csv.exists():
        faq_df = pd.read_csv(faq_csv)
        faq = faq_jsonld(faq_df)
        with open(DIST / "faq.jsonld", "w", encoding="utf-8") as f:
            json.dump(faq, f, ensure_ascii=False, indent=2)

    print("已完成：dist/jsonld 目錄內包含：")
    print(" - products_all.jsonld（合併）")
    print(" - 各產品 *.jsonld（單品）")
    print(" - collection_*.jsonld（分類）")
    print(" - faq.jsonld（常見問題，可選）")

if __name__ == "__main__":
    main()
