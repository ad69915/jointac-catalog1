
# Jointac JSON-LD 自動化專案（手機/電腦皆可）

本專案用來把「展通交通器材」的產品資料，轉成搜尋引擎與 AI 模型最友善的結構化資料（JSON-LD）。

## 你只要做兩步
1. **填寫 `data/products.csv`（手機可編輯）**
2. **執行產生器** → 會在 `dist/jsonld/` 產生：
   - `products_all.jsonld`（全部合併）
   - `*.jsonld`（每個產品各一檔）
   - `collection_分類.jsonld`（各分類 ProductCollection）
   - `faq.jsonld`（可選，來自 `data/faq.csv`）

## 產出後怎麼上線
把 `dist/jsonld/*.jsonld` 的內容**複製貼到各頁 `<head>`**：
```html
<script type="application/ld+json"> …貼在這… </script>
```
- 單品頁：貼 `@type: Product` 對應檔案內容
- 分類頁：貼 `@type: ProductCollection` 與 `@type: FAQPage`（可選）

## （選擇）GitHub Actions 自動化
若要用 GitHub 自動生成：
1. 建立 Repo，放入本專案所有檔案
2. 每次更新 `data/products.csv` 後 push
3. GitHub Actions 會自動跑 `scripts/generate_jsonld.py`
4. 你可在工作流中加上部署步驟（FTP/SFTP/SSH），把結果送到網站主機

## 結構說明
- `data/products.csv`：產品清單（先填幾筆，後續擴展）
- `data/faq.csv`：FAQ 清單（可選）
- `scripts/generate_jsonld.py`：將 CSV 轉為 JSON-LD 的腳本
- `dist/jsonld/`：輸出結果

## 檢查正確性
用 Google「Rich Results Test」測試產品頁網址，看 JSON-LD 是否正確被讀取。

---
若要我幫你把現有官網全產品轉檔，只要把「分類/產品頁網址清單」丟給我，我即可批次完成。
